package com.silver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhoenixApplicationTests {

	@Test
	void contextLoads() {
	}

}
